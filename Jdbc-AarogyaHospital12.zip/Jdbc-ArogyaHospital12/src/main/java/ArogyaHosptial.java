
public class ArogyaHosptial {

	public static void main(String [] args) {
	DaoInterface dao=new DaoImpl();
	Patient p=new Patient();
	/*
	p.setId(102);
	p.setAge(20);
	p.setName("musthafa");
	p.setGender("male");
	p.setCity("guntur");
	p.setAddress("2-448,guntur");
	p.setGuardian_name("baji");
	p.setGuardian_address("2-44");
    p.setDateOfAdmission("1992/08/22");
    p.setAadhar_Card_number(1234525);
    p.setContact_number(9618925);
    p.setGuardian_contactNumber(77023625);
    
    dao.patientRegistration(p);
    */
	
	//dao.viewAllPatient();
	
	//dao.searchPatientById(101);
	
	//dao.deletePatientById(101);
	
	//dao.searchPatientByCity("guntur");
	
	//dao.searchPatientByAgeGroup(18, 55);
	
 }

}